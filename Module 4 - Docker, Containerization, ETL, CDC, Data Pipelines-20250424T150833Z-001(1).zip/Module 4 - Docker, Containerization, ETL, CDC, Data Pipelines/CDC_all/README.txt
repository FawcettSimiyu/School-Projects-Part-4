	Install all python modules shown in the #pip lines in the codes.
	Setup all necessary Docker containers as shown in the container.py. 
	Correct/modify all necessary lines in the codes to successfully perform the following tasks:

	1. Run the container.py Python program from the command prompt passing -create as a parameter. 
	2. Then, again run the container.py Python program from the command prompt passing -init as a parameter. This will ensure that your databases are initialized. Provide a screenshot of the command prompt showing that you successfully executed the program. Note that you may need to run the following two pip commands from the command prompt to install pymysql:pip install pymysqlpip install cryptographyMake sure that the database containers are running before you run the command.
	3. Run the scheduler.py Python program from the command prompt. Provide a screenshot of your Terminal window showing the scheduler.py program running and the output.
	4. Stop the scheduler.py program by closing the command prompt window. Run the container.py command from the command prompt passing -delete as a parameter. Provide a screenshot of the command prompt showing that you successfully ran the command.
	5. Provide a screenshot of your Docker desktop showing that both database containers have been removed.