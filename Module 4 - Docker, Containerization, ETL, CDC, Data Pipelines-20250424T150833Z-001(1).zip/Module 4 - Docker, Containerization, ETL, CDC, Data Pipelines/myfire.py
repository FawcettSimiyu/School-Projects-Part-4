# firebase - backend as a service, BaaS
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

# Fetch the service account key JSON file contents
cred = credentials.Certificate('mykey.json')

# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://course-test-default-rtdb.firebaseio.com/'
})

# save data
ref = db.reference('py/')
users_ref = ref.child('users')
users_ref.set({
    'user1': {
        'date_of_birth': 'January 23, 1980',
        'full_name': 'James Caldwell'
    },
    'user2': {
        'date_of_birth': 'August 12, 1975',
        'full_name': 'William Murlas'
    }
})

# update data
hopper_ref = users_ref.child('user2')
hopper_ref.update({
    'nickname': 'Papa Bear'
})

# read data
handle = db.reference('py/users/user1')

# Read the data at the posts reference (this is a blocking operation)
print(ref.get())