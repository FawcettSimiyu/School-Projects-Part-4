package psu.se411.coursemanagement;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import psu.se411.coursemanagement.database.DatabaseConnection;

public class CourseManagement extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        DatabaseConnection.initializeDatabase(); // Ensure table exists

        FXMLLoader fxmlLoader = new FXMLLoader(CourseManagement.class.getResource("CourseView.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        primaryStage.setTitle("Course Management System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}