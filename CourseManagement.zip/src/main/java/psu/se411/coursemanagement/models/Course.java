package psu.se411.coursemanagement.models;

import javafx.beans.property.*;

public class Course {
    private final StringProperty id;
    private final StringProperty name;
    private final StringProperty instructor;
    private final DoubleProperty credits;
    private final StringProperty schedule;

    // Constructor
    public Course(String id, String name, String instructor, int credits, String schedule) {
        this.id = new SimpleStringProperty(id);
        this.name = new SimpleStringProperty(name);
        this.instructor = new SimpleStringProperty(instructor);
        this.credits = new SimpleDoubleProperty(credits);
        this.schedule = new SimpleStringProperty(schedule);
    }

    // Getters and Property Methods for JavaFX TableView binding
    public String getId() { return id.get(); }
    public void setId(String value) { id.set(value); }
    public StringProperty idProperty() { return id; }

    public String getName() { return name.get(); }
    public void setName(String value) { name.set(value); }
    public StringProperty nameProperty() { return name; }

    public String getInstructor() { return instructor.get(); }
    public void setInstructor(String value) { instructor.set(value); }
    public StringProperty instructorProperty() { return instructor; }

    public double getCredits() { return credits.get(); }
    public void setCredits(int value) { credits.set(value); }
    public DoubleProperty creditsProperty() { return credits; }

    public String getSchedule() { return schedule.get(); }
    public void setSchedule(String value) { schedule.set(value); }
    public StringProperty scheduleProperty() { return schedule; }
}


