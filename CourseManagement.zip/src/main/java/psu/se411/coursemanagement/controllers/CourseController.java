package psu.se411.coursemanagement.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import psu.se411.coursemanagement.models.Course;
import psu.se411.coursemanagement.services.CourseService;

public class CourseController {
    @FXML private TextField idField;
    @FXML private TextField nameField;
    @FXML private TextField instructorField;
    @FXML private TextField creditsField;
    @FXML private TextField scheduleField;
    @FXML private TableView<Course> courseTable;
    @FXML private TableColumn<Course, String> idColumn;
    @FXML private TableColumn<Course, String> nameColumn;
    @FXML private TableColumn<Course, String> instructorColumn;
    @FXML private TableColumn<Course, Double> creditsColumn;
    @FXML private TableColumn<Course, String> scheduleColumn;

    private CourseService courseService;
    private ObservableList<Course> courseList;

    public void initialize() {
        courseService = new CourseService();
        courseList = FXCollections.observableArrayList(courseService.getCourses());

        idColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getId()));
        nameColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));
        instructorColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getInstructor()));
        creditsColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getCredits()).asObject());
        scheduleColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getSchedule()));

        courseTable.setItems(courseList);
    }

    @FXML
    private void addCourse() {
        Course course = new Course(
                idField.getText(),
                nameField.getText(),
                instructorField.getText(),
                Integer.parseInt(creditsField.getText()),
                scheduleField.getText()
        );
        courseService.addCourse(course);
        courseList.add(course);
        clearFields();
    }

    @FXML
    private void removeCourse() {
        Course selectedCourse = courseTable.getSelectionModel().getSelectedItem();
        if (selectedCourse != null) {
            courseService.removeCourse(selectedCourse.getId());
            courseList.remove(selectedCourse);
        }
    }

    private void clearFields() {
        idField.clear();
        nameField.clear();
        instructorField.clear();
        creditsField.clear();
        scheduleField.clear();
    }
}


