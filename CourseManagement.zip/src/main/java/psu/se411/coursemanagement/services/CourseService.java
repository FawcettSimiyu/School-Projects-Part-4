package psu.se411.coursemanagement.services;


import psu.se411.coursemanagement.database.DatabaseConnection;
import psu.se411.coursemanagement.models.Course;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseService {
    public void addCourse(Course course) {
        String sql = "INSERT INTO courses (id, name, instructor, credits, schedule) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, course.getId());
            pstmt.setString(2, course.getName());
            pstmt.setString(3, course.getInstructor());
            pstmt.setDouble(4, course.getCredits());
            pstmt.setString(5, course.getSchedule());
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeCourse(String courseId) {
        String sql = "DELETE FROM courses WHERE id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, courseId);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Course> getCourses() {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT * FROM courses";

        try (Connection conn = DatabaseConnection.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                courses.add(new Course(
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getString("instructor"),
                        rs.getInt("credits"),
                        rs.getString("schedule")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }
}


