module psu.se411.coursemanagement {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens psu.se411.coursemanagement to javafx.fxml;
    exports psu.se411.coursemanagement;
    exports psu.se411.coursemanagement.controllers;
    opens psu.se411.coursemanagement.controllers to javafx.fxml;
}